<?php
class ormdb
{
    function inputdata($inputdata)
    {
        require 'rb.php';
        R::setup("mysql:host=localhost;dbname=db_login;", "pswrite", "fa123456");
        $post = R::dispense('post');
        $post->_author = 'Amin Zirak';
        $post->_title = 'redbean';
        $id = R::store($post);

    }

    function readdata($readdata)
    {
        require 'rb.php';
        R::setup("mysql:host=localhost;dbname=db_login;", "pswrite", "fa123456");
        $id=1;
        $mypost=R::load('post',$id);
        echo $mypost->_arthur.'<br/>';
        echo $mypost->_title;
        $id = R::store($post);
    }
    function updatadata($updatdata)
    {
       /* require 'rb.php';
        R::setup("mysql:host=localhost;dbname=db_login;", "pswrite", "fa123456");
        $post = R::dispense('post');
        $post->_author = 'Amin Zirak';
        $post->_title = 'redbean';
        $id = R::store($post);*/
    }

    function dropdata($dropdata)
    {
        require 'rb.php';
        R::setup("mysql:host=localhost;dbname=db_login;", "pswrite", "fa123456");
        $id=2;
        $mypost=R::load('post',$id);
        R::trash($mypost);
        $id = R::store($post);
    }

}


?>