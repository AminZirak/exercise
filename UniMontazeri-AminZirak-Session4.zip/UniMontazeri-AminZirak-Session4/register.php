<form action="functions.php" method="POST">

    <div class="form-group">
        <label>Firstname</label>
        <input type="text" class="form-control" name="firstname" />
    </div>
    <div class="form-group">
        <label>Lastname</label>
        <input type="text" class="form-control" name="lastname" />
    </div>
    <div class="form-group">
        <label>Codemeli</label>
        <input type="text" class="form-control" name="codemeli" />
    </div>
    <div class="form-group">
        <label>Phone</label>
        <input type="text" class="form-control" name="phone" />
    </div>
    <div class="form-group">
        <label>Username</label>
        <input type="text" class="form-control" name="username" />
    </div>
    <div class="form-group">
        <label>Password</label>
        <input type="password" class="form-control" name="password" />
    </div>
    <br />
    <div class="form-group">
        <button class="btn btn-primary form-control" name="register">Register</button>
    </div>
</form>